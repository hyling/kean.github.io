import Foundation

// MARK: - Parser

public struct Parser<A> {
    /// Parses the given string. Returns the matched element `A` and the
    /// remaining substring if the match is succesful. Returns `nil` otherwise.
    public let parse: (_ string: Substring) throws -> (A, Substring)?

    public init(_ parse: @escaping (_ string: Substring) throws -> (A, Substring)?) {
        self.parse = parse
    }
}

public extension Parser {
    func parse(_ string: String) throws -> A? {
        try parse(string[...])?.0
    }
}

// MARK: - Parser (Combinators)

public extension Parser {
    func map<B>(_ transform: @escaping (A) throws -> B?) -> Parser<B> {
        flatMap { match in
            Parser<B> { str in
                guard let value = try transform(match) else { return nil }
                return (value, str)
            }
        }
    }

    func flatMap<B>(_ transform: @escaping (A) throws -> Parser<B>) -> Parser<B> {
        Parser<B> { str in
            guard let (a, str) = try self.parse(str) else { return nil }
            return try transform(a).parse(str)
        }
    }

    func filter(_ predicate: @escaping (A) -> Bool) -> Parser<A> {
        map { predicate($0) ? $0 : nil }
    }
}

// MARK: - Parser (Quantifiers)

public extension Parser {
    /// Matches the given parser zero or more times.
    var zeroOrMore: Parser<[A]> {
        Parser<[A]> { str in
            var str = str
            var matches = [A]()
            while let (match, newStr) = try self.parse(str) {
                matches.append(match)
                str = newStr
            }
            return (matches, str)
        }
    }

    /// Matches the given parser one or more times.
    var oneOrMore: Parser<[A]> {
        zeroOrMore.map { $0.isEmpty ? nil : $0 }
    }

    /// Matches of the parser produces no matches (inverts the parser).
    var zero: Parser<Void> {
        map { _ in nil }
    }
}

public func optional<A>(_ parser: Parser<A>) -> Parser<A?> {
    Parser<A?> { str -> (A?, Substring)? in // yes, double-optional, zip unwraps it
          guard let match = try parser.parse(str) else {
              return (nil, str) // Return empty match without consuming any characters
          }
          return match
      }
}

// MARK: - Parser (More Combinators)

/// Matches only if both of the given parsers produced a result.
public func zip<A, B>(_ a: Parser<A>, _ b: Parser<B>) -> Parser<(A, B)> {
    a.flatMap { matchA in b.map { matchB in (matchA, matchB) } }
}

public func zip<A, B, C>(_ a: Parser<A>, _ b: Parser<B>, _ c: Parser<C>) -> Parser<(A, B, C)> {
    zip(a, zip(b, c)).map { a, bc in (a, bc.0, bc.1) }
}

public func zip<A, B, C, D>(_ a: Parser<A>, _ b: Parser<B>, _ c: Parser<C>, _ d: Parser<D>) -> Parser<(A, B, C, D)> {
    zip(a, zip(b, c, d)).map { a, bcd in (a, bcd.0, bcd.1, bcd.2) }
}

public func zip<A, B, C, D, E>(_ a: Parser<A>, _ b: Parser<B>, _ c: Parser<C>, _ d: Parser<D>, _ e: Parser<E>) -> Parser<(A, B, C, D, E)> {
    zip(a, zip(b, c, d, e)).map { a, bcde in (a, bcde.0, bcde.1, bcde.2, bcde.3) }
}

// MARK: - Extensions

public extension CharacterSet {
    /// Returns true if all of the unicode scalars in the given character
    /// are in the characer set.
    func contains(_ c: Character) -> Bool {
        return c.unicodeScalars.allSatisfy(contains)
    }
}

// MARK: - Parser (Operators)

infix operator *> : CombinatorPrecedence
infix operator <* : CombinatorPrecedence
infix operator <*> : CombinatorPrecedence

public func *> <A, B>(_ lhs: Parser<A>, _ rhs: Parser<B>) -> Parser<B> {
    zip(lhs, rhs).map { $0.1 }
}

public func <* <A, B>(_ lhs: Parser<A>, _ rhs: Parser<B>) -> Parser<A> {
    zip(lhs, rhs).map { $0.0 }
}

public func <*> <A, B>(_ lhs: Parser<A>, _ rhs: Parser<B>) -> Parser<(A, B)> {
    zip(lhs, rhs)
}

precedencegroup CombinatorPrecedence {
    associativity: left
    higherThan: DefaultPrecedence
}

// MARK: - Parser (Predefined)

/// Matches the given string.
public func string(_ p: String) -> Parser<Void> {
    Parser { str in
        str.hasPrefix(p) ? ((), str.dropFirst(p.count)) : nil
    }
}

/// Matches any single character.
public let char = Parser<Character> { str in
    str.isEmpty ? nil : (str.first!, str.dropFirst())
}

/// Matches a single digit.
public let digit = char.filter(CharacterSet.decimalDigits.contains)

/// Parsers a natural number or zero. Valid inputs: "0", "1", "10".
public let number = digit.oneOrMore.map { Int(String($0)) }

extension Parser: ExpressibleByStringLiteral, ExpressibleByUnicodeScalarLiteral, ExpressibleByExtendedGraphemeClusterLiteral where A == Void {
    // Unfortunately had to add these explicitly supposably because of the
    // conditional conformance limitations.
    public typealias ExtendedGraphemeClusterLiteralType = StringLiteralType
    public typealias UnicodeScalarLiteralType = StringLiteralType
    public typealias StringLiteralType = String

    public init(stringLiteral value: String) {
        self = string(value)
    }
}
