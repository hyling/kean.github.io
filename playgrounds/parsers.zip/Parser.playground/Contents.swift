import Foundation

struct RangeQuantifier {
    let lowerBound: Int
    let upperBound: Int?
}

// MARK: Version 1

do {
    let rangeQuantifier = zip("{", number, ",", optional(number), "}")
        .map { _, lowerBound, _, upperBound, _ in
            RangeQuantifier(lowerBound: lowerBound, upperBound: upperBound)
        }

    rangeQuantifier.parse("{1,3}") // Returns 1...3
    rangeQuantifier.parse("{1,3") // Returns nil
    rangeQuantifier.parse("{1,}") // Returns 1...
}

// MARK: Version 2 (with custom operators)

do {
    let rangeQuantifier = ("{" *> number <* "," <*> optional(number) <* "{").map(RangeQuantifier.init)

    rangeQuantifier.parse("{1,3}") // Returns 1...3
    rangeQuantifier.parse("{1,3") // Returns nil
    rangeQuantifier.parse("{1,}") // Returns 1...
}
